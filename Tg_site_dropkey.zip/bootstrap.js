document.addEventListener("DOMContentLoaded", function () {
    loadMenu();
    initTg();

    console.log("Version app 0.2");
});